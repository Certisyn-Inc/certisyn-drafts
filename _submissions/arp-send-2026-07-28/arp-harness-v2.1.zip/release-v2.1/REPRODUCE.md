# ARP harness v2.1 -- reproduction package

Everything Songbo asked for on 28 July: the executable scripts, the exact
dependency versions, the command lines, the repository URLs with pinned
commits, and the non-corpus fixtures. Nothing in this package reads the
network. Every number in the accompanying post is produced by one of the
four commands below.

## 1. Environment

    Python   3.11.15 (CPython, GCC 13.3.0)
    cryptography  46.0.7        <- the ONLY third-party dependency

Everything else is the Python standard library. `pip install cryptography`
is sufficient. If `cryptography` is absent the harness still runs and says
so on its banner; signature legs then report as unverified rather than
silently passing.

    pip install "cryptography==46.0.7"

## 2. Repositories, pinned

    EMILIA Protocol
      https://github.com/emiliaprotocol/emilia-protocol
      125e4f4311f1319fef3f6d55c935c9ea4da5fc1b
      (feat(gate): ship bounded Autonomy Control Plane (#393), 2026-07-26)

    Noa
      https://github.com/NordenSoft/noa
      21eadb38ae494cbeb64d7773486ed7c4a8417754
      (Remediate CodeQL findings and expand security gates (#13), 2026-07-22)

    EATF verifier / CPB corpus
      https://github.com/tyche-institute/eatf-verifier
      cb49226cc0cb0b36ae90c3f0b214e0e7998e7a60
      (docs: record the published Zenodo v0.4.1 archive DOI, 2026-07-27)

    ARP draft source
      https://github.com/Certisyn-Inc/scitt-arp-f39
      branch feat/revision-02-canonicalization

Clone each at the pinned commit:

    git clone https://github.com/emiliaprotocol/emilia-protocol && \
      git -C emilia-protocol checkout 125e4f4311f1319fef3f6d55c935c9ea4da5fc1b
    git clone https://github.com/NordenSoft/noa && \
      git -C noa checkout 21eadb38ae494cbeb64d7773486ed7c4a8417754
    git clone https://github.com/tyche-institute/eatf-verifier && \
      git -C eatf-verifier checkout cb49226cc0cb0b36ae90c3f0b214e0e7998e7a60

## 3. Commands

    # (a) the main run: EMILIA frozen-v1 + the Noa receipt corpus
    python3 arp_reconcile.py \
      --emilia <emilia-protocol>/conformance/clean-room/frozen-v1 \
      --noa    <noa>/conformance \
      --json   arp_run_v21.json

    # (b) the EATF / CPB corpus, BOTH configurations. The two differ and the
    #     difference is a finding, so neither is "the" run.
    python3 arp_eatf.py --corpus <eatf-verifier>/test-vectors \
      --no-trust-anchor --json eatf_run_v2_noanchor.json
    python3 arp_eatf.py --corpus <eatf-verifier>/test-vectors \
      --json eatf_run_v2_anchor.json

    # (c) the EMILIA AEB boundary-vector adapter
    python3 arp_adapter.py

    # (d) ARP-OUTCOME-VECTORS v0.2, two-sided
    python3 run_outcome_vectors.py --caid-repo <emilia-protocol>

Vector file v0.2 is itself generated, not hand-written. To regenerate and
confirm it is byte-identical:

    python3 build_outcome_vectors_v02.py --caid-repo <emilia-protocol> \
      --out /tmp/regen.json && diff /tmp/regen.json arp-outcome-vectors-v0.2.json

## 4. Non-corpus fixtures in this package

    arp-aeb-adapter-v0.1.json      EMILIA's boundary vector, as received,
                                   unmodified. sha256
                                   1e5d6a6b156f956e846ef3f4a5df6fa35efbe8197b5556106d2e060c70f59f2e
    arp-outcome-vectors-v0.1.json  superseded; kept so the supersession is
                                   checkable rather than asserted
    arp-outcome-vectors-v0.2.json  the shipped vector set

No other fixture is used. Everything else is read from the pinned corpora.

## 5. Expected outputs

    arp_run_v21.json
      sha256 a9af97909b6ef330563b706555dc66aaeca83e9a38fa4ff0896147e7bc19f23b

    arp_outcome_vectors_v02_run.json   5 passed, 0 failed
    arp_adapter_run.json               5 of 5

For reference, the v2 run this supersedes had
`arp_run_v2.json` sha256
04fa5fb12185029df4c159982cdb3d541a8e701a1fb9d44fb549a5288561a38b,
which Songbo reproduced independently from fresh checkouts. v2.1 differs
from it in exactly two rows; see CHANGES-v2.1.md.

## 6. Script hashes

    00b10162e7bba48b9fc300cf07be124e9b454d86a8b9453aa716ce4a2b6e03bf  arp_reconcile.py
    267bcbf5f29fd74a6630920834e9ddab8bbb82cc294af8efac2c34b43221cc7c  arp_eatf.py
    1c36cb4c98d2c4e425a24287c654c9544385a25efb5d72386dfc6a4d347cb24d  arp_adapter.py
    7c659009bf4a797c0a75062ad04db9b738ade9c3afec259699c231c4d5f6fe05  run_outcome_vectors.py
    48ba59166e6426ae4bd05a28707a8625fe2e36e076de0245d5e0395ea537e366  build_outcome_vectors_v02.py
    8726e9f178ea94bb2b255af808bd0761e3f2f46473fcd403413fce5ab1db1b35  arp-outcome-vectors-v0.2.json

The v1 harness that produced the first posted run remains byte-identical and
is not in this package; its md5 is 99240731f9947355de11006f91904d4d and it has
not been touched since it was posted.

Third-party code this package calls but does not vendor: the CAID reference
implementation at <emilia-protocol>/caid/impl/python/caid.py, sha256
d5edfdef62093eadffba06d7846f31f20691f7b658f14035bd95250280b24651, and the
action-type registry at <emilia-protocol>/caid/registry/action-types.json,
sha256 8352b1d5e33d608999d6e285cf67fa3bdd7ac5b818d54700193b09ad49daf9d6.
Both are read from your checkout, never from mine.
