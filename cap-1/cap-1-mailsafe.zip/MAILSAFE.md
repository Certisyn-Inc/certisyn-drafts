# Why the Node files arrived as `.mjs.txt`

Google refuses any message carrying a `.mjs` file, including inside a `.zip`.
It is on their published blocked-extension list and the block applies to
archive contents, so the canonical `cap-1.zip` cannot reach a Gmail or Google
Workspace address at all. It is rejected at the SMTP layer with
`552-5.7.0 ... content presents a potential security issue`.

Nothing has been removed. The nine Node files are byte-identical to the
canonical package; only the extension differs.

## Restore them

Linux or macOS:

    for f in *.mjs.txt; do mv "$f" "${f%.txt}"; done

Windows PowerShell:

    Get-ChildItem *.mjs.txt | Rename-Item -NewName { $_.Name -replace '\.txt$','' }

Then follow `REPRODUCE.md` as written. `verify.py` and `verify.html` are
unaffected and run without the rename.

## Digests

`cap-1.zip`, the canonical package, is the one the run records and
`RUN-CAP-1.ps1` are pinned against:

    SHA-256  645dcc47a0082e48da2b6ffb654ec94e58f304d941e14bf2aaa6f6e378e0cac0

This mail-safe repack has a different digest because nine filenames differ.
Its digest is stated in the covering email. After the rename above, every file
digest matches the canonical package and `all.sh` reproduces the same five run
records.
